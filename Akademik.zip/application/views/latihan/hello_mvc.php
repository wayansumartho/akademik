<!DOCTYPE html>
<html>
<head>
	<title>Halo Dunia</title>
</head>
<body>
	<h2><?php echo $hello; ?></h2>
</body>
</html>