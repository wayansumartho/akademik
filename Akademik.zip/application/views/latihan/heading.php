<!DOCTYPE html>
<html lang="on">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width-device-width, initial-scale=1.0">
	<title>Documents</title>
</head>
<body>
	<?php
	//fucntion heading berada di dalam helper HTML, sehingga untuk menggunakan harus di panggil
	//terlebih dahulu helper HTML
	echo heading ("Implementasi salah satu fungsi yang berada dihelper HTML, yaitu membuat heading 1", 1);
	?>

</body>
</html>