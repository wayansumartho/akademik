<center><br><br><br><br><br><br><br><br>
    <img src="../assets2/images/amikom.png" width="200px height=" 200px" /> <br>
    <font Size="6" face="Helvetica">Sistem Informasi Akademik</font> <br>
    <font Size="6">Universitas Amikom Yogyakarta</font>
</center>