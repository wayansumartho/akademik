</div>
<!-- /page content -->

<!-- footer content -->
<footer>
    <div class="pull-right">
        Copyright @ 2020 Web Akademik : Choco Latte
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->
</div>
</div>

<!-- jQuery -->
<script src="../assets2/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../assets2/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- FastClick -->
<script src="../assets2/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="../assets2/nprogress/nprogress.js"></script>
<!-- bootstrap-progressbar -->
<script src="../assets2/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="../assets2/iCheck/icheck.min.js"></script>
<!-- Skycons -->
<script src="../assets2/skycons/skycons.js"></script>
<!-- Custom Theme Scripts -->
<script src="../assets2/js/custom.min.js"></script>


</body>

</html>